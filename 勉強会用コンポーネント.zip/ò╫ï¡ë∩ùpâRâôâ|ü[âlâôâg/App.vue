<template>
  <v-app dark>
    <!--    Input my contests    -->
    <v-content>
      <Header />
      <Top />
      <Footer />
    </v-content>
  </v-app>
</template>

<script>
import "@mdi/font/css/materialdesignicons.css"; // Ensure you are using css-loader
import Top from "./components/Top";
import Header from "./components/header";
import Footer from "./components/footer";
// import Works from "./components/Works";
// import TopPage from "./components/TopPage";

export default {
  name: "App",
  components: {
    // TopPage,
    Header,
    Top,
    Footer,

    // Works,
  },
  icons: {
    iconfont: "mdi", // default - only for display purposes
  },
};
</script>
